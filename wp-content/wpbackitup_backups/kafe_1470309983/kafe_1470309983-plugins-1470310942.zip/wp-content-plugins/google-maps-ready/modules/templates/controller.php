<?php
class templatesController extends controllerGmp {

}