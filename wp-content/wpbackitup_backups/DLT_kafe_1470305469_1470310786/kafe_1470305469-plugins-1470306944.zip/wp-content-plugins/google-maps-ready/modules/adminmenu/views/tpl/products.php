<h1>Default products page</h1>
