<?php echo $this->marker['address']?>
<br />
<pre><?php langGmp::_e('Latitude')?> : <?php echo $this->marker['coord_y'];?><br /><?php langGmp::_e('Longitude')?> : <?php echo $this->marker['coord_x'];?><br /></pre>