<?php
class csvViewGmp extends viewGmp {
	public function getSettitngsBlockHtml() {
		return parent::getContent('csvSettitngsBlockHtml');
	}
}