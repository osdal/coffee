<?php
class shortcodesControllerGmp extends controllerGmp {
    
}

